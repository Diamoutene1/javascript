"use strict";

let listeVoitures = [
    {
        "marque": "Audi",
        "modele": "A4",
        "etat": "bon"
    },
    {
        "marque": "Peugeot",
        "modele": "3008",
        "etat": "excellent"
    },
    {
        "marque": "Renault",
        "modele": "Clio",
        "etat": "roulante"
    },
    {
        "marque": "Toyota",
        "modele": "Auris",
        "etat": "moyen"
    },
    {
        "marque": "BMW",
        "modele": "310",
        "etat": "moyen"
    },
    {
        "marque": "Citroen",
        "modele": "Picasso",
        "etat": "excelent"
    },
    {
        "marque": "Fiat",
        "modele": "500",
        "etat": "roulante"
    },
    {
        "marque": "Porsche",
        "modele": "911",
        "etat": "bon"
    },
    {
        "marque": "Peugeot",
        "modele": "405",
        "etat": "bon"
    },
    {
        "marque": "Renault",
        "modele": "Supercinq",
        "etat": "moyen"
    },
    {
        "marque": "Ford",
        "modele": "Mustang",
        "etat": "bon"
    },
    {
        "marque": "Peugeot",
        "modele": "308",
        "etat": "moyen"
    },
    {
        "marque": "Renault",
        "modele": "Twingo",
        "etat": "excellent"
    },
    {
        "marque": "Citroen",
        "modele": "C1",
        "etat": "roulante"
    },
    {
        "marque": "Honda",
        "modele": "Accord",
        "etat": "bon"
    },
    {
        "marque": "Fiat",
        "modele": "Leon",
        "etat": "excellent"
    }
]